#!/bin/bash
# launch.sh — submit seeding simulation as a single job with 16 cores
# All 240 simulations (8 seed rules x 3 tiers x 10 reps) run in parallel.
#
# Expects these files in calibration_jobs/seeding/:
#   arcane_seeding_incidence_cluster.R
#   tier_analysis.csv  (from Outputs/prevalence/compiled/ after incidence calibration)

ARCANE_ROOT=/media/kevinNFS2/rany/calibration_jobs
SCRIPT=${ARCANE_ROOT}/seeding/script.sh

# Create output and log folders
mkdir -p ${ARCANE_ROOT}/Outputs/seeding
mkdir -p ${ARCANE_ROOT}/seeding/logs

echo "Submitting seeding simulation job..."
qsub ${SCRIPT}

echo "Done. Monitor with: qstat -u kevin"
echo "Log: ${ARCANE_ROOT}/seeding/logs/seeding.log"
