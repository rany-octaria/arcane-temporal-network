# =============================================================================
# arcane_seeding_incidence.R  —  Seeding simulation using calibrated betas
# =============================================================================
# Loads tier_analysis.csv from the incidence calibration and uses the
# mean_beta + 95% CI to draw a per-hospital beta for each simulation rep.
#
# Three incidence tiers:
#   Low  (0.03-0.15 /1k pd): from calibration results
#   Mid  (0.15-0.60 /1k pd): from calibration results
#   High (0.60-1.50 /1k pd): EXTRAPOLATED — not reached in current grid;
#                             extend beta_grid in calibration_incidence.R
#                             to get calibrated values for this tier.
#
# Per-hospital beta draw (each rep, each hospital):
#   beta_h ~ truncnorm(mean = tier$mean_beta,
#                      sd   = (ci_hi - ci_lo) / (2 * 1.96),
#                      a    = 1e-4, b = 0.30)
#
# This propagates the full calibration uncertainty into each simulation.
# =============================================================================

library(parallel)
library(dplyr)
library(tidyr)
library(truncnorm)
library(igraph)

# ── igraph masks tidyr::crossing — restore it ─────────────────────────────────
crossing <- tidyr::crossing

# =============================================================================
# 0. PATHS
# =============================================================================

ARCANE_ROOT <- Sys.getenv("ARCANE_ROOT",
                           "/media/kevinNFS2/rany/calibration_jobs")
DATA_DIR   <- file.path(ARCANE_ROOT, "data")
TIER_FILE  <- file.path(ARCANE_ROOT, "seeding", "tier_analysis.csv")
OUT_DIR    <- file.path(ARCANE_ROOT, "Outputs", "seeding")
dir.create(OUT_DIR, recursive = TRUE, showWarnings = FALSE)

# =============================================================================
# 1. LOAD TIER ANALYSIS + ADD HIGH TIER PLACEHOLDER
# =============================================================================

tier_raw <- read.csv(TIER_FILE, stringsAsFactors = FALSE)

# SD from 95% CI width
tier_raw <- tier_raw %>%
  mutate(beta_sd = (ci_hi_95 - ci_lo_95) / (2 * 1.96),
         beta_sd = if_else(beta_sd <= 0 | is.na(beta_sd),
                            mean_beta * 0.10,   # fallback: 10% CV
                            beta_sd))

# High tier: EXTRAPOLATED — simulation grid did not reach 0.60-1.50 /1k pd.
# Update these values once the cluster calibration covers higher betas.
high_tier <- data.frame(
  tier         = "High",
  inc_low      = 0.60,
  inc_high     = 1.50,
  n_qualifying = NA_integer_,
  n_betas      = NA_integer_,
  best_beta    = 0.050,
  mean_beta    = 0.050,
  median_beta  = 0.050,
  ci_lo_95     = 0.035,
  ci_hi_95     = 0.080,
  mean_inc_ach = NA_real_,
  beta_sd      = (0.080 - 0.035) / (2 * 1.96),
  stringsAsFactors = FALSE
)

tier_df <- bind_rows(tier_raw, high_tier) %>%
  mutate(tier     = factor(tier, levels = c("Low","Mid","High")),
         source   = c(rep("calibrated", nrow(tier_raw)), "extrapolated")) %>%
  arrange(tier)

cat("\n=== TIER BETA PARAMETERS ===\n")
print(tier_df %>%
        select(tier, inc_low, inc_high, mean_beta, beta_sd,
               ci_lo_95, ci_hi_95, source),
      row.names = FALSE)

# =============================================================================
# 2. SIMULATION SETTINGS
# =============================================================================

N_REP          <- 10
N_SEED_INF     <- 5L
Tmax           <- 365L
gamma          <- 1 / 387
alpha          <- 0
pi_vec_val     <- 0.001
N_CORES        <- max(1L, parallel::detectCores() - 1L)
CLUSTER_MODE   <- TRUE    # FORK on Linux cluster

message("Reps: ", N_REP, " | Tmax: ", Tmax, "d | pi_vec: ", pi_vec_val,
        " | Cores: ", N_CORES)

# =============================================================================
# 3. DATA LOADING + HOSPITAL UNIVERSE
# =============================================================================

weekly_transfers <- readRDS(file.path(DATA_DIR, "weekly.RDS")) %>%
  mutate(weight = pmax(1L, as.integer(round(weight / 7))))

facility_level <- readRDS(file.path(DATA_DIR, "facility_level_final.RDS")) %>%
  mutate(finess_geo = as.character(finess_geo)) %>%
  rename(incidence_esbl_all = incidence_region_type_ESBL_all)

default_los <- facility_level %>%
  filter(!is.na(hospital_type)) %>%
  group_by(hospital_type) %>%
  summarise(pt  = sum(pt_days_total, na.rm=TRUE),
            pat = sum(patient_total,  na.rm=TRUE), .groups="drop") %>%
  mutate(los_type = pt / pat)
DEFAULT_LOS_TYPE   <- setNames(default_los$los_type, default_los$hospital_type)
GLOBAL_DEFAULT_LOS <- with(
  facility_level %>% filter(!is.na(hospital_type)) %>%
    summarise(a=sum(pt_days_total,na.rm=TRUE),
              b=sum(patient_total, na.rm=TRUE)), a/b)

hospitals <- bind_rows(
  weekly_transfers %>% transmute(finess_geo=as.character(finess_geo_origin)),
  weekly_transfers %>% transmute(finess_geo=as.character(finess_geo_target))
) %>% distinct() %>%
  left_join(
    facility_level %>% transmute(
      finess_geo, hospital_type, type_spares, region,
      no_beds = as.integer(round(census_max)),
      los     = pmax(as.numeric(los_mean), 1.0)
    ), by="finess_geo"
  ) %>%
  mutate(
    no_beds       = as.integer(if_else(is.na(no_beds),
                                        as.integer(round(mean(no_beds,na.rm=TRUE))),
                                        no_beds)),
    los           = coalesce(los, DEFAULT_LOS_TYPE[hospital_type],
                              GLOBAL_DEFAULT_LOS),
    type_spares   = if_else(is.na(type_spares),   "Unknown", type_spares),
    hospital_type = if_else(is.na(hospital_type), "Unknown", hospital_type),
    region        = if_else(is.na(region),         "Unknown", region)
  )

H              <- nrow(hospitals)
beds           <- hospitals$no_beds
p_exit         <- 1 / hospitals$los
pi_vec         <- rep(pi_vec_val, H)
type_etab      <- hospitals$type_spares
total_beds_sum <- sum(beds)

transfer_out <- weekly_transfers %>%
  transmute(origin=as.character(finess_geo_origin), weight) %>%
  group_by(origin) %>%
  summarise(total_out=sum(weight,na.rm=TRUE), .groups="drop")
hospitals <- hospitals %>%
  left_join(transfer_out, by=c("finess_geo"="origin")) %>%
  mutate(total_out=replace(total_out, is.na(total_out), 0))
p_tr <- pmin(hospitals$total_out / pmax(p_exit*beds, 1), 0.60)

message("Building P_tr (", H, " x ", H, ")...")
hosp_idx     <- setNames(seq_len(H), hospitals$finess_geo)
transfer_agg <- weekly_transfers %>%
  transmute(orig=hosp_idx[as.character(finess_geo_origin)],
            dest=hosp_idx[as.character(finess_geo_target)], weight) %>%
  filter(!is.na(orig) & !is.na(dest)) %>%
  group_by(orig, dest) %>%
  summarise(weight=sum(weight), .groups="drop")
P_tr <- matrix(0.0, H, H)
for (k in seq_len(nrow(transfer_agg)))
  P_tr[transfer_agg$dest[k], transfer_agg$orig[k]] <- transfer_agg$weight[k]
cs <- colSums(P_tr)
for (h in seq_len(H)) if (cs[h]>0) P_tr[,h] <- P_tr[,h]/cs[h]
transfer_idx <- which(p_tr > 0 & colSums(P_tr) > 0)
message("  Done. H=", H, " | Transfer-eligible: ", length(transfer_idx))

# =============================================================================
# 4. PER-HOSPITAL BETA DRAWS — one vector per (tier, rep)
# =============================================================================
# For each tier and rep, draw an independent beta_vec of length H.
# Each hospital's beta is drawn from:
#   truncnorm(mean = tier$mean_beta,
#             sd   = (ci_hi_95 - ci_lo_95) / (2 x 1.96),
#             a    = 1e-4, b = 0.30)
# This gives each hospital a slightly different beta reflecting calibration
# uncertainty, while keeping the distribution centred on the tier estimate.
# =============================================================================

set.seed(42)
beta_draws <- lapply(levels(tier_df$tier), function(t) {
  tr    <- tier_df[tier_df$tier == t, ]
  mn    <- tr$mean_beta
  sd    <- tr$beta_sd
  lapply(seq_len(N_REP), function(r)
    rtruncnorm(H, a = 1e-4, b = 0.30, mean = mn, sd = sd)
  )
}) %>% setNames(levels(tier_df$tier))

message("\nBeta draws per tier (mean across hospitals):")
for (t in names(beta_draws)) {
  vals <- sapply(beta_draws[[t]], mean)
  message(sprintf("  %-6s mean=%.5f  sd=%.5f  range=[%.5f, %.5f]",
                  t, mean(vals), sd(vals), min(vals), max(vals)))
}

# =============================================================================
# 5. SEED PANEL — network metrics + type-stratified random
# =============================================================================

g_agg <- weekly_transfers %>%
  group_by(finess_geo_origin, finess_geo_target) %>%
  summarise(weight=sum(weight), .groups="drop") %>%
  igraph::graph_from_data_frame(directed=TRUE)

in_deg  <- igraph::degree(g_agg, mode="in")
out_deg <- igraph::degree(g_agg, mode="out")
out_str <- igraph::strength(g_agg, mode="out")
btwn    <- igraph::betweenness(g_agg, directed=TRUE, normalized=FALSE)

seed_metrics <- hospitals %>%
  left_join(
    tibble(finess_geo   = names(in_deg),
           in_degree    = as.integer(in_deg),
           out_degree   = as.integer(out_deg[names(in_deg)]),
           out_strength = as.numeric(out_str[names(in_deg)]),
           betweenness  = as.numeric(btwn[names(in_deg)])),
    by = "finess_geo"
  ) %>%
  mutate(across(c(in_degree, out_degree, out_strength, betweenness),
                ~ replace_na(.x, 0)))

fixed_seeds <- bind_rows(
  seed_metrics %>% slice_max(in_degree,    n=1, with_ties=FALSE) %>%
    transmute(finess_geo, seed_rule="highest_in_degree"),
  seed_metrics %>% slice_max(out_degree,   n=1, with_ties=FALSE) %>%
    transmute(finess_geo, seed_rule="highest_out_degree"),
  seed_metrics %>% slice_max(betweenness,  n=1, with_ties=FALSE) %>%
    transmute(finess_geo, seed_rule="highest_betweenness"),
  seed_metrics %>% slice_max(no_beds,      n=1, with_ties=FALSE) %>%
    transmute(finess_geo, seed_rule="largest_beds"),
  seed_metrics %>% slice_max(out_strength, n=1, with_ties=FALSE) %>%
    transmute(finess_geo, seed_rule="largest_outgoing")
) %>%
  group_by(finess_geo) %>%
  summarise(seed_rule=paste(sort(seed_rule), collapse=" + "),
            .groups="drop") %>%
  mutate(seed_type="fixed")

type_seeds <- tibble(
  finess_geo = NA_character_,
  seed_rule  = c("random_MCO","random_SSR","random_MCO_SSR"),
  seed_type  = "type_random"
)

seed_panel <- bind_rows(fixed_seeds, type_seeds)
message("Seed rules (", nrow(seed_panel), "): ",
        paste(seed_panel$seed_rule, collapse=", "))

hosp_by_type <- hospitals %>%
  group_by(hospital_type) %>%
  summarise(ids=list(finess_geo), .groups="drop") %>%
  with(setNames(ids, hospital_type))

# =============================================================================
# 6. SIMULATION GRID — tier x seed_rule x rep
# =============================================================================

sim_grid <- seed_panel %>%
  tidyr::crossing(
    tibble(tier   = levels(tier_df$tier),
           rep_id = rep(seq_len(N_REP), length(levels(tier_df$tier)))) %>%
      arrange(tier, rep_id)
  ) %>%
  mutate(
    sim_id   = row_number(),
    sim_seed = 10000L + sim_id * 7L,
    seed_hospital = mapply(
      function(stype, srule, fgeo, sseed) {
        if (stype == "fixed") return(fgeo)
        target <- switch(srule,
          random_MCO     = "MCO",
          random_SSR     = "SSR",
          random_MCO_SSR = "MCO/SSR",
          "Other")
        pool <- hosp_by_type[[target]]
        if (is.null(pool) || length(pool)==0) pool <- hospitals$finess_geo
        set.seed(sseed); sample(pool, 1)
      },
      seed_type, seed_rule, finess_geo, sim_seed,
      SIMPLIFY=TRUE, USE.NAMES=FALSE
    )
  )

message("Total simulations: ", nrow(sim_grid),
        " (", nrow(seed_panel), " rules x ",
        length(levels(tier_df$tier)), " tiers x ", N_REP, " reps)")

# =============================================================================
# 7. SIMULATION FUNCTION
# =============================================================================

run_seeding_simulation <- function(seed_hospital, sim_seed, beta_vec) {
  set.seed(sim_seed)
  p_rec <- 1 - exp(-gamma)

  I_loc <- integer(H)
  idx   <- which(hospitals$finess_geo == seed_hospital)
  if (length(idx) > 0)
    I_loc[idx] <- min(as.integer(N_SEED_INF), beds[idx])
  S_loc <- beds - I_loc

  daily <- vector("list", Tmax)

  for (t in seq_len(Tmax)) {
    N       <- S_loc + I_loc
    p_inf   <- ifelse(N > 0L & is.finite(beta_vec),
                      1 - exp(-beta_vec * I_loc / pmax(N, 1L)), 0)
    new_inf <- rbinom(H, S_loc, p_inf)
    recov   <- rbinom(H, I_loc, p_rec)
    S_loc   <- S_loc - new_inf + recov
    I_loc   <- I_loc + new_inf - recov

    n_exit_S <- rbinom(H, S_loc, p_exit)
    n_exit_I <- rbinom(H, I_loc, p_exit)
    S_loc    <- S_loc - n_exit_S
    I_loc    <- I_loc - n_exit_I

    S_tr <- numeric(H); I_tr <- numeric(H)
    active_h <- transfer_idx[(n_exit_S[transfer_idx]+
                                n_exit_I[transfer_idx])>0L]
    for (h in active_h) {
      nS <- rbinom(1L, n_exit_S[h], p_tr[h])
      nI <- rbinom(1L, n_exit_I[h], p_tr[h])
      if ((nS+nI)==0L) next
      probs <- P_tr[,h]; s <- sum(probs); if (s<=0) next
      if (nS>0L) S_tr <- S_tr + rmultinom(1L,nS,probs)[,1L]
      if (nI>0L) I_tr <- I_tr + rmultinom(1L,nI,probs)[,1L]
    }

    occ   <- S_loc + I_loc + S_tr + I_tr
    A     <- pmax(0L, beds - occ)
    A_I   <- rbinom(H, A, pi_vec)
    S_loc <- S_loc + S_tr + (A - A_I)
    I_loc <- I_loc + I_tr + A_I

    daily[[t]] <- data.frame(
      day                  = t,
      total_infected       = sum(I_loc),
      n_hospitals_infected = sum(I_loc > 0L),
      overall_prevalence   = sum(I_loc) / total_beds_sum,
      incidence_daily      = sum(new_inf) / max(sum(N), 1) * 1000,
      pathogen_extinct     = sum(I_loc) == 0L
    )
  }

  do.call(rbind, daily)
}

# =============================================================================
# 8. RUN IN PARALLEL — FORK (Linux cluster)
# =============================================================================

message("\nStarting cluster: ", N_CORES, " FORK workers...")
if (exists("cl") && inherits(cl,"cluster")) try(stopCluster(cl), silent=TRUE)
cl <- makeCluster(N_CORES, type = "FORK")

t0 <- Sys.time()
message("Running ", nrow(sim_grid), " simulations...")

results_list <- tryCatch({
  parLapply(cl, seq_len(nrow(sim_grid)), function(i) {
    row    <- sim_grid[i,]
    bvec   <- beta_draws[[as.character(row$tier)]][[row$rep_id]]
    ts     <- run_seeding_simulation(row$seed_hospital, row$sim_seed, bvec)
    ts$sim_id        <- row$sim_id
    ts$seed_rule     <- row$seed_rule
    ts$seed_type     <- row$seed_type
    ts$tier          <- as.character(row$tier)
    ts$rep_id        <- row$rep_id
    ts$seed_hospital <- row$seed_hospital
    ts
  })
}, finally = {
  message("Stopping cluster...")
  try(stopCluster(cl), silent=TRUE)
})

elapsed <- round(difftime(Sys.time(), t0, units="mins"), 1)
message("Done. Elapsed: ", elapsed, " min")

# =============================================================================
# 9. COMPILE AND SAVE
# =============================================================================

all_results <- bind_rows(results_list)

seed_meta <- seed_metrics %>%
  select(finess_geo, hospital_type, region,
         in_degree, out_degree, betweenness, no_beds)

all_results <- all_results %>%
  left_join(seed_meta, by=c("seed_hospital"="finess_geo"))

sim_summary <- all_results %>%
  group_by(sim_id, seed_rule, seed_type, tier, rep_id,
           seed_hospital, hospital_type, region) %>%
  summarise(
    peak_infected        = max(total_infected),
    day_of_peak          = day[which.max(total_infected)],
    peak_hospitals       = max(n_hospitals_infected),
    final_infected       = total_infected[day==max(day)],
    final_prevalence     = overall_prevalence[day==max(day)],
    ever_extinct         = any(pathogen_extinct),
    day_extinct          = if (any(pathogen_extinct))
                             min(day[pathogen_extinct]) else NA_integer_,
    .groups              = "drop"
  ) %>%
  left_join(tier_df %>%
              select(tier, mean_beta, beta_sd, ci_lo_95, ci_hi_95, source) %>%
              mutate(tier=as.character(tier)),
            by="tier")

run_date <- format(Sys.Date(), "%Y%m%d")

saveRDS(list(all_results=all_results, sim_summary=sim_summary,
             tier_df=tier_df, sim_grid=sim_grid,
             params=list(N_REP=N_REP, Tmax=Tmax, N_SEED_INF=N_SEED_INF,
                         pi_vec=pi_vec_val, gamma=gamma)),
        file.path(OUT_DIR, paste0("seeding_results_", run_date, ".rds")))

write.csv(sim_summary,
          file.path(OUT_DIR, paste0("seeding_summary_", run_date, ".csv")),
          row.names=FALSE)

cat("\n=== DONE ===\n")
cat("Simulations :", nrow(sim_grid), "\n")
cat("Elapsed     :", elapsed, "min\n")
cat("Saved to    :", OUT_DIR, "\n")
cat("\nExtinction by tier:\n")
print(sim_summary %>%
        group_by(tier) %>%
        summarise(pct_extinct=round(mean(ever_extinct)*100,1),
                  .groups="drop"))
