#!/bin/bash
#PBS -N seeding_incidence
#PBS -q mem128G
#PBS -l nodes=1:ppn=16
#PBS -l walltime=48:00:00
#PBS -j oe

# Redirect all output to log file — available at runtime
exec > /media/kevinNFS2/rany/calibration_jobs/seeding/logs/seeding.log 2>&1

echo "======================================================="
echo "ARCANE — Seeding Simulation"
echo "Node    : $(hostname)"
echo "Started : $(date)"
echo "======================================================="

ARCANE_ROOT=/media/kevinNFS2/rany/calibration_jobs
export ARCANE_ROOT

cd ${ARCANE_ROOT}

Rscript --vanilla seeding/arcane_seeding_incidence_cluster.R

EXIT_CODE=$?

echo "======================================================="
echo "Finished  : $(date)"
echo "Exit code : ${EXIT_CODE}"
echo "======================================================="

exit $EXIT_CODE
