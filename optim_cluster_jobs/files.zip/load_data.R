# =============================================================================
# load_data.R  —  shared data loading and structural parameter construction
# -----------------------------------------------------------------------------
# Sourced by both optim_france.R and optim_region.R AFTER the driver has set:
#   DATA_DIR      folder containing weekly.RDS + facility_level_final.RDS
#   MAX_P_TR      cap on daily transfer probability (e.g. 0.60)
#   DEFAULT_LOS   named vector of fallback LOS by facility type
#
# Exposes for the driver:
#   weekly_transfers  cleaned transfer edge table
#   facility_level    cleaned facility attribute table
#   facility_targets  four-tier incidence target per finess_geo
#   hospitals         one row per network node (finess_geo) with all attrs
#   hosp_idx          named integer: finess_geo → row index in hospitals
#   H                 number of network hospitals
#   beds              integer vector (length H): census_max bed capacity
#   p_exit            numeric vector (length H): daily discharge probability
#   p_tr              numeric vector (length H): daily transfer fraction
#   P_tr              H×H matrix: column-normalised transfer probabilities
#   type_etab_calib   character vector (length H): facility_type per hospital
#   incidence_obs     named numeric vector: France-wide SPARES target per type
#   spares_types      data frame: facility types with real SPARES signal
#   global_inc        scalar: global fallback incidence rate
# =============================================================================

library(dplyr)
library(readr)

# =============================================================================
# 1. RAW DATA
# =============================================================================
weekly_transfers <- readRDS(file.path(DATA_DIR, "weekly.RDS")) %>%
  mutate(weight = pmax(1L, as.integer(round(weight / 7))))

# facility_level_final.RDS: raw column names are type_spares and
# incidence_region_type_ESBL_all — renamed immediately on load.
facility_level <- readRDS(file.path(DATA_DIR, "facility_level_final.RDS")) %>%
  mutate(finess_geo = as.character(finess_geo)) %>%
  rename(
    facility_type      = type_spares,
    incidence_esbl_all = incidence_region_type_ESBL_all
  )

# =============================================================================
# 2. FOUR-TIER INCIDENCE TARGETS
#    (a) own SPARES rate  (b) type×region mean  (c) regional mean  (d) global
# =============================================================================
global_inc <- mean(facility_level$incidence_esbl_all, na.rm = TRUE)

type_region_inc <- facility_level %>%
  group_by(facility_type, region) %>%
  summarise(type_region_mean_inc = mean(incidence_esbl_all, na.rm = TRUE),
            .groups = "drop")

region_inc <- facility_level %>%
  group_by(region) %>%
  summarise(region_mean_inc = mean(incidence_esbl_all, na.rm = TRUE),
            .groups = "drop")

facility_targets <- facility_level %>%
  left_join(type_region_inc, by = c("facility_type", "region")) %>%
  left_join(region_inc,      by = "region") %>%
  mutate(
    target_incidence = case_when(
      !is.na(incidence_esbl_all)   ~ incidence_esbl_all,
      !is.na(type_region_mean_inc) ~ type_region_mean_inc,
      !is.na(region_mean_inc)      ~ region_mean_inc,
      TRUE                         ~ global_inc
    ),
    incidence_source = case_when(
      !is.na(incidence_esbl_all)   ~ "facility",
      !is.na(type_region_mean_inc) ~ "type_region_mean",
      !is.na(region_mean_inc)      ~ "region_mean",
      TRUE                         ~ "global_mean"
    )
  ) %>%
  select(finess_geo, facility_type, region, target_incidence, incidence_source)

# =============================================================================
# 3. HOSPITAL UNIVERSE (all network nodes)
# =============================================================================
hospitals <- bind_rows(
  weekly_transfers %>% transmute(finess_geo = as.character(finess_geo_origin)),
  weekly_transfers %>% transmute(finess_geo = as.character(finess_geo_target))
) %>% distinct()

mean_beds <- round(mean(facility_level$census_max, na.rm = TRUE))

hospitals <- hospitals %>%
  left_join(
    facility_level %>%
      transmute(finess_geo,
                no_beds    = as.integer(round(census_max)),
                los        = pmax(as.numeric(los_mean), 1.0),
                region,
                facility_type),
    by = "finess_geo"
  ) %>%
  mutate(
    no_beds       = as.integer(if_else(is.na(no_beds), mean_beds, no_beds)),
    los           = coalesce(los, DEFAULT_LOS[facility_type], 7.0),
    los           = pmax(los, 1.0)
  ) %>%
  left_join(facility_targets, by = "finess_geo") %>%
  mutate(
    target_incidence = if_else(is.na(target_incidence), global_inc, target_incidence),
    facility_type    = if_else(is.na(facility_type), "Unknown", facility_type),
    incidence_source = if_else(is.na(incidence_source), "global_mean", incidence_source),
    region           = if_else(is.na(region), "Unknown", region)
  )

# Named row-index lookup: finess_geo → integer position in hospitals
hosp_idx <- setNames(seq_len(nrow(hospitals)), hospitals$finess_geo)

H    <- nrow(hospitals)
beds <- hospitals$no_beds

# =============================================================================
# 4. DISCHARGE PROBABILITY  p_exit[h] = 1 / LOS[h]
# =============================================================================
p_exit <- 1 / hospitals$los

# =============================================================================
# 5. TRANSFER PROBABILITY  p_tr[h] = daily_transfers_out / daily_discharges
# =============================================================================
transfer_out_df <- weekly_transfers %>%
  transmute(origin = as.character(finess_geo_origin), weight) %>%
  group_by(origin) %>%
  summarise(total_out = sum(weight, na.rm = TRUE), .groups = "drop")

hospitals <- hospitals %>%
  left_join(transfer_out_df, by = c("finess_geo" = "origin")) %>%
  mutate(
    total_out = replace(total_out, is.na(total_out), 0),
    p_tr_raw  = total_out / pmax(p_exit * beds, 1)
  )

p_tr <- pmin(hospitals$p_tr_raw, MAX_P_TR)

# =============================================================================
# 6. DENSE TRANSFER PROBABILITY MATRIX  P_tr  (H × H)
#    P_tr[dest, origin] = probability a transfer from 'origin' goes to 'dest'
#    Columns are normalised to sum to 1 (or 0 for hospitals with no outflow).
# =============================================================================
message("Building P_tr matrix (", H, " × ", H, ") ...")

transfer_agg <- weekly_transfers %>%
  transmute(
    orig   = hosp_idx[as.character(finess_geo_origin)],
    dest   = hosp_idx[as.character(finess_geo_target)],
    weight
  ) %>%
  filter(!is.na(orig) & !is.na(dest)) %>%
  group_by(orig, dest) %>%
  summarise(weight = sum(weight), .groups = "drop")

P_tr <- matrix(0.0, nrow = H, ncol = H)
for (k in seq_len(nrow(transfer_agg))) {
  P_tr[transfer_agg$dest[k], transfer_agg$orig[k]] <- transfer_agg$weight[k]
}

# Column-normalise: each column sums to 1 (or stays 0)
col_sums <- colSums(P_tr)
for (h in seq_len(H)) {
  if (col_sums[h] > 0) P_tr[, h] <- P_tr[, h] / col_sums[h]
}
message("  P_tr built. Non-zero columns: ",
        sum(col_sums > 0), " of ", H)

# =============================================================================
# 7. FACILITY TYPE AND FRANCE-WIDE INCIDENCE TARGETS
# =============================================================================
type_etab_calib <- hospitals$facility_type

# Types with real SPARES signal (tiers a/b/c, not global fill)
spares_types <- facility_targets %>%
  filter(incidence_source != "global_mean") %>%
  distinct(facility_type)

target_type <- hospitals %>%
  group_by(facility_type) %>%
  summarise(target_incidence = mean(target_incidence), .groups = "drop")

# incidence_obs: France-wide mean target per type (SPARES types only)
incidence_obs <- target_type %>%
  semi_join(spares_types, by = "facility_type") %>%
  with(setNames(target_incidence, facility_type))

message("France-wide calibration types (", length(incidence_obs), "): ",
        paste(names(incidence_obs), collapse = ", "))
message("Observed incidence targets (per 1,000 bed-days):")
print(round(incidence_obs, 3))
