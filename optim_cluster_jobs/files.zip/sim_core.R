# =============================================================================
# sim_core.R  —  simulation function + objective + checkpoint helpers
# -----------------------------------------------------------------------------
# Sourced AFTER the driver has defined:
#   H, beds, p_exit, p_tr, P_tr, pi_vec, prev_init_etab, type_etab_calib
#   incidence_obs, Tmax, last_year_start, last_year_len, gamma, alpha
#   cl, rep_chunks, n_rep_obj, n_cores, seed_objective
#   checkpoint_last_file, checkpoint_best_file, history_file
#   eval_counter, best_value  (initialised to 0L and Inf respectively)
#   current_start_id          (initialised to NA_integer_)
#
# ALGORITHM: identical to the original 01_Beta_Calibration_OPTIM_SPARES.R —
#   per-hospital SIS loop, handle_exit closure for transfers, dense P_tr matrix.
# =============================================================================


# =============================================================================
# SIMULATION FUNCTION
# =============================================================================
run_simulation_summary <- function(beta_vec, alpha, seed = NULL) {

  if (!is.null(seed)) set.seed(seed)

  p_rec <- 1 - exp(-gamma)

  # Initialise state
  I_loc <- rbinom(H, beds, prev_init_etab)
  S_loc <- beds - I_loc

  inc_sum_last <- numeric(H)

  for (t in seq_len(Tmax)) {

    # ── SIS within-hospital transmission (per-hospital loop) ────────────────
    for (i in seq_len(H)) {
      N <- S_loc[i] + I_loc[i]
      if (N <= 0) next

      p_inf   <- 1 - exp(-beta_vec[i] * I_loc[i] / N)
      new_inf <- rbinom(1, S_loc[i], p_inf)
      recov   <- rbinom(1, I_loc[i], p_rec)

      if (t >= last_year_start) {
        inc_sum_last[i] <- inc_sum_last[i] + new_inf
      }

      S_loc[i] <- S_loc[i] - new_inf + recov
      I_loc[i] <- I_loc[i] + new_inf - recov
    }

    # ── Transfers ────────────────────────────────────────────────────────────
    S_stay <- S_loc
    I_stay <- I_loc
    S_tr   <- numeric(H)
    I_tr   <- numeric(H)

    # handle_exit uses <<- to write back to the outer loop's S_stay/I_stay/S_tr/I_tr
    handle_exit <- function(h) {

      n_exit_S <- rbinom(1, S_loc[h], p_exit[h])
      n_exit_I <- rbinom(1, I_loc[h], p_exit[h])

      if ((n_exit_S + n_exit_I) == 0) return()

      S_stay[h] <<- S_stay[h] - n_exit_S
      I_stay[h] <<- I_stay[h] - n_exit_I

      p_tr_h <- p_tr[h]

      n_tr_S <- rbinom(1, n_exit_S, p_tr_h)
      n_tr_I <- rbinom(1, n_exit_I, pmin(pmax((1 - alpha) * p_tr_h, 0), 1))

      if ((n_tr_S + n_tr_I) > 0) {

        probs_dest <- P_tr[, h]
        if (!all(is.finite(probs_dest))) return()
        s <- sum(probs_dest)
        if (s <= 0) return()
        probs_dest <- probs_dest / s

        if (n_tr_S > 0) {
          dest_S <- rmultinom(1, n_tr_S, probs_dest)
          S_tr <<- S_tr + dest_S[, 1]
        }
        if (n_tr_I > 0) {
          dest_I <- rmultinom(1, n_tr_I, probs_dest)
          I_tr <<- I_tr + dest_I[, 1]
        }
      }
    }

    for (h in seq_len(H)) handle_exit(h)

    # ── Community admissions ─────────────────────────────────────────────────
    occ  <- S_stay + I_stay + S_tr + I_tr
    A    <- pmax(0L, beds - occ)
    A_I  <- rbinom(H, A, pi_vec)
    A_S  <- A - A_I

    S_loc <- S_stay + S_tr + A_S
    I_loc <- I_stay + I_tr + A_I
  }

  # ── Incidence per 1,000 bed-days → type-level mean ───────────────────────
  inc_etab <- 1000 * inc_sum_last / (beds * last_year_len)
  tapply(inc_etab, type_etab_calib, mean, na.rm = TRUE)[names(incidence_obs)]
}


# =============================================================================
# CHECKPOINT HELPERS
# =============================================================================
safe_saveRDS <- function(object, file) {
  tmp <- paste0(file, ".tmp")
  saveRDS(object, tmp)
  if (file.exists(file)) file.remove(file)
  file.rename(tmp, file)
}

save_objective_state <- function(beta_type_log, beta_type, incidence_sim,
                                 objective_value, sse_by_type,
                                 is_best, start_id = NA_integer_) {
  state <- list(
    datetime = Sys.time(), eval_counter = eval_counter,
    start_id = start_id, objective_value = objective_value,
    sse_by_type = sse_by_type, is_best = is_best,
    n_rep_obj = n_rep_obj, n_cores = n_cores,
    seed_objective = seed_objective, beta_type_log = beta_type_log,
    beta_type = beta_type, incidence_sim = incidence_sim,
    incidence_obs = incidence_obs, lower_beta = lower_beta,
    upper_beta = upper_beta, checkpoint_dir = checkpoint_dir
  )
  safe_saveRDS(state, checkpoint_last_file)
  if (is_best) safe_saveRDS(state, checkpoint_best_file)

  beta_cols <- as.data.frame(as.list(beta_type), check.names = FALSE)
  inc_cols  <- as.data.frame(as.list(incidence_sim), check.names = FALSE)
  sse_cols  <- as.data.frame(as.list(sse_by_type), check.names = FALSE)
  names(beta_cols) <- paste0("beta_",    names(beta_type))
  names(inc_cols)  <- paste0("inc_sim_", names(incidence_sim))
  names(sse_cols)  <- paste0("sse_",     names(sse_by_type))

  hist_row <- cbind(
    data.frame(eval_counter = eval_counter,
               datetime = format(Sys.time(), "%Y-%m-%d %H:%M:%S"),
               start_id = start_id, objective_value = objective_value,
               best_value = best_value, is_best = is_best,
               n_rep_obj = n_rep_obj, stringsAsFactors = FALSE),
    beta_cols, inc_cols, sse_cols
  )
  write.table(hist_row, file = history_file, sep = ";", dec = ".",
              row.names = FALSE,
              col.names  = !file.exists(history_file),
              append     =  file.exists(history_file))
}


# =============================================================================
# OBJECTIVE FUNCTION
# =============================================================================
current_start_id <- NA_integer_

objective_fn <- function(beta_type_log) {
  eval_counter <<- eval_counter + 1L

  beta_type        <- exp(beta_type_log)
  names(beta_type) <- names(incidence_obs)
  beta_vec         <- beta_type[as.character(type_etab_calib)]

  # Fallback for facility types with no SPARES-derived target
  if (anyNA(beta_vec)) {
    beta_vec[is.na(beta_vec)] <- mean(beta_type, na.rm = TRUE)
  }

  results <- parLapply(
    cl, X = rep_chunks,
    fun = function(rs, beta_vec, seed_objective, alpha) {
      do.call(rbind, lapply(rs, function(r)
        run_simulation_summary(beta_vec = beta_vec, alpha = alpha,
                               seed = seed_objective + r)))
    },
    beta_vec = beta_vec, seed_objective = seed_objective, alpha = alpha
  )

  inc_mat         <- do.call(rbind, results)
  incidence_sim   <- colMeans(inc_mat, na.rm = TRUE)[names(incidence_obs)]
  sse_by_type     <- (incidence_sim - incidence_obs)^2
  objective_value <- sum(sse_by_type, na.rm = TRUE)

  is_best <- objective_value < best_value
  if (is_best) best_value <<- objective_value

  save_objective_state(beta_type_log, beta_type, incidence_sim,
                       objective_value, sse_by_type, is_best,
                       start_id = current_start_id)

  cat(sprintf("  [%4d] start=%-6s  SSE=%.5f  best=%.5f  %s\n",
              eval_counter, as.character(current_start_id),
              objective_value, best_value,
              if (is_best) "<-- BEST" else ""))
  cat("  Simulated: "); print(round(incidence_sim, 3))
  cat("  Observed : "); print(round(incidence_obs, 3))

  objective_value
}


# =============================================================================
# BOUNDED OBJECTIVE (log-space with quadratic boundary penalty)
# =============================================================================
lower_log <- log(lower_beta)
upper_log <- log(upper_beta)

objective_bounded <- function(beta_type_log) {
  if (any(!is.finite(beta_type_log))) return(1e12)
  penalty <- sum(pmax(beta_type_log - upper_log, 0)^2 +
                   pmax(lower_log - beta_type_log, 0)^2)
  if (penalty > 0) return(1e9 + 1e9 * penalty)
  objective_fn(beta_type_log)
}


# =============================================================================
# NELDER-MEAD MULTI-START LOOP
# =============================================================================
run_nelder_mead <- function(starts, fits_file) {

  fits <- vector("list", length(starts))
  names(fits) <- names(starts)

  for (i in seq_along(starts)) {
    current_start_id <<- i

    cat("\n############################################################\n")
    cat(sprintf("Start %d/%d  (%s)\nBeta: %s\n",
                i, length(starts), names(starts)[i],
                paste(round(exp(starts[[i]]), 5), collapse = ", ")))
    cat("############################################################\n")

    fits[[i]] <- tryCatch(
      optim(par = starts[[i]], fn = objective_bounded, method = "Nelder-Mead",
            control = list(maxit = maxit_nm, trace = 1, REPORT = 1,
                           reltol = 1e-4,
                           parscale = rep(1, length(starts[[i]])))),
      error = function(e) {
        message("  optim() error: ", conditionMessage(e))
        list(par = starts[[i]], value = Inf,
             convergence = NA_integer_, message = conditionMessage(e))
      }
    )

    safe_saveRDS(list(datetime = Sys.time(), fits = fits,
                      eval_counter = eval_counter, best_value = best_value),
                 fits_file)

    cat(sprintf("  → SSE=%.6f  convergence=%s\n",
                fits[[i]]$value, fits[[i]]$convergence))
  }

  current_start_id <<- NA_integer_
  fits
}


# =============================================================================
# BEST BETA RECOVERY (from checkpoint or final optim result)
# =============================================================================
recover_best_beta <- function(fits, checkpoint_best_file) {

  fit_values  <- sapply(fits, function(x) x$value)
  best_fit_id <- which.min(fit_values)

  cat("\n============================================================\n")
  cat("Final SSE by start:\n")
  print(round(fit_values, 6))
  cat(sprintf("Best start: %s  SSE=%.6f\n",
              names(fits)[best_fit_id], fit_values[best_fit_id]))

  if (file.exists(checkpoint_best_file)) {
    ckpt          <- readRDS(checkpoint_best_file)
    beta_type_opt <- ckpt$beta_type
    beta_type_log_opt <- ckpt$beta_type_log
    cat(sprintf("Checkpoint SSE: %.6f\n", ckpt$objective_value))
    if (ckpt$objective_value > fit_values[best_fit_id]) {
      cat("Using optim() result (better than checkpoint).\n")
      beta_type_opt     <- exp(fits[[best_fit_id]]$par)
      names(beta_type_opt) <- names(incidence_obs)
      beta_type_log_opt <- log(beta_type_opt)
    } else {
      cat("Using checkpoint result.\n")
    }
  } else {
    beta_type_opt     <- exp(fits[[best_fit_id]]$par)
    names(beta_type_opt) <- names(incidence_obs)
    beta_type_log_opt <- log(beta_type_opt)
  }

  beta_type_opt <- pmin(pmax(beta_type_opt[names(incidence_obs)],
                             lower_beta), upper_beta)
  list(beta_type_opt = beta_type_opt,
       beta_type_log_opt = log(beta_type_opt),
       fit_values = fit_values, best_fit_id = best_fit_id)
}


# =============================================================================
# FINAL VALIDATION
# =============================================================================
run_validation <- function(beta_opt, rep_chunks_valid, seed_validation) {

  cat(sprintf("\nRunning validation (%d replicates)...\n", n_rep_valid))

  res <- parLapply(
    cl, X = rep_chunks_valid,
    fun = function(rs, beta_opt, seed_validation, alpha) {
      do.call(rbind, lapply(rs, function(r)
        run_simulation_summary(beta_vec = beta_opt, alpha = alpha,
                               seed = seed_validation + r)))
    },
    beta_opt = beta_opt, seed_validation = seed_validation, alpha = alpha
  )

  mat      <- do.call(rbind, res)
  inc_mean <- colMeans(mat, na.rm = TRUE)[names(incidence_obs)]
  inc_sd   <- apply(mat, 2, sd, na.rm = TRUE)[names(incidence_obs)]
  inc_se   <- inc_sd / sqrt(n_rep_valid)
  diff_v   <- (inc_mean - incidence_obs)[names(incidence_obs)]
  sse_v    <- diff_v^2
  sse_tot  <- sum(sse_v, na.rm = TRUE)

  list(inc_mean = inc_mean, inc_sd = inc_sd, inc_se = inc_se,
       diff = diff_v, sse_by_type = sse_v, sse_total = sse_tot, mat = mat)
}
