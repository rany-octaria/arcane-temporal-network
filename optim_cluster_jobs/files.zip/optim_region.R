# =============================================================================
# optim_region.R  —  PER-REGION beta calibration driver
# =============================================================================
# Optimises one beta per facility type within a single French administrative
# region.  jobindex (1…N_regions) selects which region to process.
# Only within-region hospitals and transfers are used; inter-regional
# transfers are dropped and the P_tr sub-matrix is re-normalised.
# =============================================================================

library(parallel)

# =============================================================================
# 0. KNOBS  (same structure as optim_france.R)
# =============================================================================
JOB_INDEX <- {
  v <- suppressWarnings(as.integer(Sys.getenv("jobindex")))
  if (!is.na(v) && v > 0L) v else 1L
}

n_cores <- {
  v <- suppressWarnings(as.integer(Sys.getenv("NCPUS")))
  if (!is.na(v) && v > 0L) max(1L, v - 1L) else 4L
}

n_rep_obj      <- 100
n_rep_valid    <- 300
n_random_starts <- 6
maxit_nm       <- 100

seed_objective     <- 2000  + (JOB_INDEX - 1L) * 10000L
seed_validation    <- 60000 + (JOB_INDEX - 1L) * 10000L
seed_random_starts <- 456   + (JOB_INDEX - 1L) * 10000L

lower_beta <- 1e-5
upper_beta <- 0.10

GAMMA_CLEAR    <- 1 / 387
ADMISSION_PREV <- 0.05
INIT_PREV      <- 0.02
alpha          <- 0
gamma          <- GAMMA_CLEAR

MAX_P_TR <- 0.60
DEFAULT_LOS <- c(
  "MCO" = 5.5, "SSR" = 32.0, "MCO/SSR" = 7.0, "PSY" = 60.0,
  "HAD" = 22.0, "CLCC" = 6.0, "Other" = 8.0, "Unknown" = 7.0
)

PROJECT_ROOT <- Sys.getenv("ARCANE_ROOT", unset = "/media/kevinNFS2/rany")
JOB_DIR      <- file.path(PROJECT_ROOT, "optim_cluster_jobs")
DATA_DIR     <- file.path(JOB_DIR, "data")
SHARED_DIR   <- file.path(JOB_DIR, "shared")

# Optional warm start from the France-wide result
france_best_file <- file.path(JOB_DIR, "warm_start_france.rds")

# =============================================================================
# 1. LOAD FULL NETWORK DATA
# =============================================================================
source(file.path(SHARED_DIR, "load_data.R"))

# After load_data.R: hospitals, H (full), beds, p_exit, p_tr, P_tr,
# type_etab_calib, incidence_obs, hosp_idx, facility_targets, spares_types

# =============================================================================
# 2. SELECT FOCAL REGION FROM jobindex
# =============================================================================
all_regions <- sort(unique(hospitals$region[hospitals$region != "Unknown"]))
N_regions   <- length(all_regions)

if (JOB_INDEX > N_regions) {
  stop("jobindex (", JOB_INDEX, ") exceeds number of regions (",
       N_regions, "). Regions: ", paste(all_regions, collapse=", "))
}

focal_region <- all_regions[JOB_INDEX]
message("\n=== REGION: ", focal_region, "  (job ", JOB_INDEX,
        " of ", N_regions, ") ===")

# Safe name for folder (replace spaces/accents)
region_safe <- gsub("[^A-Za-z0-9_-]", "_", focal_region)
OUT_DIR <- file.path(JOB_DIR, "Outputs", "region", region_safe)
dir.create(OUT_DIR, recursive = TRUE, showWarnings = FALSE)

# =============================================================================
# 3. SUBSET ALL OBJECTS TO FOCAL REGION
# =============================================================================
keep_idx <- which(hospitals$region == focal_region)
if (length(keep_idx) == 0) stop("No hospitals found in region: ", focal_region)

H_reg   <- length(keep_idx)
message("Hospitals in region: ", H_reg, " of ", H, " network hospitals")

# Structural vectors (re-assigned to match sim_core.R variable names)
H               <- H_reg
beds            <- beds[keep_idx]
p_exit          <- p_exit[keep_idx]
p_tr            <- p_tr[keep_idx]
pi_vec          <- rep(ADMISSION_PREV, H)
prev_init_etab  <- rep(INIT_PREV, H)
type_etab_calib <- hospitals$facility_type[keep_idx]

# P_tr sub-matrix: keep only within-region hospitals and re-normalise
P_tr <- P_tr[keep_idx, keep_idx]
col_sums <- colSums(P_tr)
for (h in seq_len(H)) {
  if (col_sums[h] > 0) P_tr[, h] <- P_tr[, h] / col_sums[h]
}
message("P_tr sub-matrix: ", H, " × ", H,
        "  | non-zero columns: ", sum(col_sums > 0))

# Simulation timing
Tmax            <- as.integer(2 * 365L)
last_year_start <- Tmax - 364L
last_year_len   <- 365L

# =============================================================================
# 4. REGION-SPECIFIC INCIDENCE TARGETS
# =============================================================================
region_hospitals <- hospitals[keep_idx, ]

# Type-level mean target within this region
region_target_type <- region_hospitals %>%
  group_by(facility_type) %>%
  summarise(target_incidence = mean(target_incidence), .groups = "drop")

# Only types with SPARES-derived targets (tiers a/b/c) in this region
spares_types_reg <- facility_targets %>%
  filter(finess_geo %in% region_hospitals$finess_geo,
         incidence_source != "global_mean") %>%
  distinct(facility_type)

incidence_obs <- region_target_type %>%
  semi_join(spares_types_reg, by = "facility_type") %>%
  with(setNames(target_incidence, facility_type))

if (length(incidence_obs) == 0) {
  stop("No SPARES-derived targets for region: ", focal_region)
}

message("Region calibration types (", length(incidence_obs), "): ",
        paste(names(incidence_obs), collapse=", "))
message("Observed incidence (per 1,000 bed-days):")
print(round(incidence_obs, 3))

# =============================================================================
# 5. CHECKPOINT PATHS
# =============================================================================
run_id         <- format(Sys.time(), "%Y%m%d_%H%M%S")
checkpoint_dir <- file.path(OUT_DIR, paste0("run_", run_id))
dir.create(checkpoint_dir, recursive = TRUE, showWarnings = FALSE)

checkpoint_best_file <- file.path(checkpoint_dir, "checkpoint_best_beta.rds")
checkpoint_last_file <- file.path(checkpoint_dir, "checkpoint_last_eval.rds")
history_file         <- file.path(checkpoint_dir, "history_objective.csv")
starts_file          <- file.path(checkpoint_dir, "starts_used.rds")
fits_file            <- file.path(checkpoint_dir, "fits_nm.rds")
final_file           <- file.path(checkpoint_dir, "final_validation.rds")
validation_csv       <- file.path(checkpoint_dir, "validation_summary.csv")

# =============================================================================
# 6. PARALLEL CLUSTER
# =============================================================================
message("Starting FORK cluster: ", n_cores, " workers")
if (exists("cl") && inherits(cl, "cluster")) try(stopCluster(cl), silent = TRUE)
cl <- makeCluster(n_cores, type = "FORK")

rep_chunks       <- split(seq_len(n_rep_obj),
                          rep(seq_len(n_cores), length.out = n_rep_obj))
rep_chunks_valid <- split(seq_len(n_rep_valid),
                          rep(seq_len(n_cores), length.out = n_rep_valid))

# =============================================================================
# 7. SOURCE SIMULATION + OBJECTIVE
# =============================================================================
eval_counter <- 0L
best_value   <- Inf
source(file.path(SHARED_DIR, "sim_core.R"))

# =============================================================================
# 8. WARM START  (from France-wide result if available)
# =============================================================================
if (file.exists(france_best_file)) {
  ws <- readRDS(france_best_file)
  beta_start <- ws$beta_type_opt[names(incidence_obs)]
  beta_start[is.na(beta_start)] <- sqrt(lower_beta * upper_beta)
  message("Warm start from France-wide result.")
} else {
  beta_start <- rep(sqrt(lower_beta * upper_beta), length(incidence_obs))
  names(beta_start) <- names(incidence_obs)
  message("No warm start — using mid-range defaults.")
}
beta_start <- pmin(pmax(beta_start, lower_beta), upper_beta)

# =============================================================================
# 9. STARTING POINTS
# =============================================================================
starts <- list()
starts[[1]] <- log(beta_start)
starts[[2]] <- log(pmin(beta_start * 1.50, upper_beta))
starts[[3]] <- log(pmax(beta_start * 0.67, lower_beta))

set.seed(seed_random_starts)
for (s in seq_len(n_random_starts)) {
  br <- beta_start * exp(runif(length(beta_start), log(0.25), log(4)))
  starts[[length(starts) + 1]] <- log(pmin(pmax(br, lower_beta), upper_beta)[names(incidence_obs)])
}
starts <- lapply(starts, function(x) pmin(pmax(x[names(incidence_obs)],
                                               lower_log), upper_log))
names(starts) <- paste0("start_", seq_along(starts))
saveRDS(list(datetime = Sys.time(), region = focal_region, starts_log = starts,
             starts_beta = lapply(starts, exp), incidence_obs = incidence_obs),
        starts_file)

# =============================================================================
# 10. NELDER-MEAD + RECOVERY + VALIDATION
# =============================================================================
tryCatch({

  fits <- run_nelder_mead(starts, fits_file)

  recovery          <- recover_best_beta(fits, checkpoint_best_file)
  beta_type_opt     <- recovery$beta_type_opt
  beta_type_log_opt <- recovery$beta_type_log_opt

  beta_opt <- beta_type_opt[as.character(type_etab_calib)]
  if (anyNA(beta_opt)) beta_opt[is.na(beta_opt)] <- mean(beta_type_opt, na.rm=TRUE)

  cat("\nOptimal beta per type (", focal_region, "):\n")
  print(round(beta_type_opt, 6))

  val <- run_validation(beta_opt, rep_chunks_valid, seed_validation)

  validation_summary <- data.frame(
    scope              = "Region",
    region             = focal_region,
    job_index          = JOB_INDEX,
    type               = names(incidence_obs),
    beta               = as.numeric(beta_type_opt[names(incidence_obs)]),
    incidence_obs      = as.numeric(incidence_obs),
    incidence_sim_mean = as.numeric(val$inc_mean),
    incidence_sim_sd   = as.numeric(val$inc_sd),
    incidence_sim_se   = as.numeric(val$inc_se),
    diff               = as.numeric(val$diff),
    sse                = as.numeric(val$sse_by_type),
    sse_total          = val$sse_total,
    stringsAsFactors   = FALSE
  )

  final_object <- list(
    datetime = Sys.time(), scope = "Region", region = focal_region,
    job_index = JOB_INDEX, H_region = H_reg, n_hospitals = H,
    beta_type_opt = beta_type_opt, beta_type_log_opt = beta_type_log_opt,
    beta_opt = beta_opt, incidence_obs = incidence_obs,
    validation = val, validation_summary = validation_summary,
    fit_values = recovery$fit_values, best_fit_id = recovery$best_fit_id,
    n_rep_obj = n_rep_obj, n_rep_valid = n_rep_valid, n_cores = n_cores,
    checkpoint_dir = checkpoint_dir
  )

  safe_saveRDS(final_object, final_file)
  write.csv2(validation_summary, file = validation_csv, row.names = FALSE)

  cat("\n=== SUMMARY  Region:", focal_region, " ===\n")
  cat("SSE total =", round(val$sse_total, 6), "\n")
  cat("Output -> ", checkpoint_dir, "\n")
  print(validation_summary[, c("type","beta","incidence_obs","incidence_sim_mean","sse")])

}, finally = {
  message("Stopping cluster ...")
  try(stopCluster(cl), silent = TRUE)
})
