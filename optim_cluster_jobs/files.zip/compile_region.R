# =============================================================================
# compile_region.R  —  aggregate all per-region job results into one table
# =============================================================================
# Run after all region jobs finish:
#   Rscript --vanilla optim_cluster_jobs/compile_region.R
#
# Produces:
#   compiled_region.rds              — full object with all region results
#   beta_by_type_region.csv          — beta per facility_type × region
#   validation_all_regions.csv       — simulated vs. observed per type × region
#   beta_heatmap.png                 — optional: heatmap of betas
# =============================================================================

library(dplyr)
library(tidyr)

PROJECT_ROOT <- Sys.getenv("ARCANE_ROOT", unset = getwd())
region_dir   <- file.path(PROJECT_ROOT, "optim_cluster_jobs",
                           "Outputs", "region")
out_dir      <- file.path(PROJECT_ROOT, "optim_cluster_jobs",
                           "Outputs", "region", "compiled")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

# ── 1. Find all per-region final_validation.rds files ────────────────────────
rds_files <- list.files(region_dir, pattern = "final_validation\\.rds$",
                         recursive = TRUE, full.names = TRUE)
rds_files <- rds_files[!grepl("/compiled/", rds_files)]

if (length(rds_files) == 0) stop("No region results found in ", region_dir)
message("Found ", length(rds_files), " region results.")

results <- lapply(rds_files, readRDS)
regions  <- sapply(results, function(r) r$region)
message("Regions processed: ", paste(sort(regions), collapse = ", "))

# ── 2. Combined validation summary (one row per type × region) ────────────────
all_summaries <- bind_rows(lapply(results, function(r) r$validation_summary))

cat("\nValidation summary (simulated vs. observed by type × region):\n")
print(all_summaries %>% select(region, type, beta, incidence_obs,
                               incidence_sim_mean, diff, sse) %>%
      arrange(region, type), n = 100)

# ── 3. Beta table: one row per region, one column per facility type ───────────
beta_wide <- bind_rows(lapply(results, function(r) {
  betas <- r$beta_type_opt
  df <- data.frame(
    region    = r$region,
    sse_total = r$validation$sse_total,
    as.data.frame(t(betas)),
    stringsAsFactors = FALSE
  )
  df
})) %>% arrange(region)

cat("\nBeta per facility type × region:\n")
print(beta_wide)

# ── 4. SSE summary by region ──────────────────────────────────────────────────
sse_summary <- data.frame(
  region    = regions,
  sse_total = sapply(results, function(r) r$validation$sse_total),
  n_hospitals = sapply(results, function(r) r$H_region),
  stringsAsFactors = FALSE
) %>% arrange(sse_total)

cat("\nSSE by region:\n")
print(sse_summary)

# ── 5. Save outputs ───────────────────────────────────────────────────────────
compiled <- list(
  datetime      = Sys.time(),
  n_regions     = length(results),
  regions       = regions,
  sse_summary   = sse_summary,
  beta_wide     = beta_wide,
  all_summaries = all_summaries,
  results       = setNames(results, regions)
)

saveRDS(compiled, file.path(out_dir, "compiled_region.rds"))
write.csv2(all_summaries, file.path(out_dir, "validation_all_regions.csv"),
           row.names = FALSE)
write.csv2(beta_wide,     file.path(out_dir, "beta_by_type_region.csv"),
           row.names = FALSE)
write.csv2(sse_summary,   file.path(out_dir, "sse_by_region.csv"),
           row.names = FALSE)

# ── 6. Optional heatmap of beta values by type × region ──────────────────────
tryCatch({
  library(ggplot2)

  beta_long <- all_summaries %>%
    select(region, type, beta) %>%
    filter(!is.na(beta))

  p <- ggplot(beta_long, aes(x = type, y = region, fill = beta)) +
    geom_tile(colour = "white") +
    geom_text(aes(label = formatC(beta, format = "e", digits = 2)),
              size = 2.5) +
    scale_fill_viridis_c(name = "β", option = "plasma", trans = "log10") +
    labs(title = "Optimal β per facility type × region",
         x = "Facility type", y = "Region") +
    theme_bw(base_size = 11) +
    theme(axis.text.x = element_text(angle = 30, hjust = 1),
          plot.title  = element_text(face = "bold"))

  ggsave(file.path(out_dir, "beta_heatmap.png"), plot = p,
         width = 10, height = 8, dpi = 150)
  message("Heatmap saved.")
}, error = function(e) message("Heatmap skipped: ", e$message))

cat("\nAll compiled outputs saved to:", out_dir, "\n")
