# =============================================================================
# optim_france.R  —  FRANCE-WIDE beta calibration driver
# =============================================================================
# Optimises one beta per facility type, pooled across all regions of France.
# Uses the algorithm from 01_Beta_Calibration_OPTIM_SPARES.R exactly:
#   per-hospital SIS loop, handle_exit closure, dense P_tr matrix.
#
# Called by france/script.sh with jobindex (1–10) controlling the RNG seeds
# and output subfolder so 10 independent runs can run in parallel.
# Pick the run with the lowest SSE as the final France-wide result.
# =============================================================================

library(parallel)

# =============================================================================
# 0. KNOBS
# =============================================================================
JOB_INDEX <- {
  v <- suppressWarnings(as.integer(Sys.getenv("jobindex")))
  if (!is.na(v) && v > 0L) v else 1L
}

n_cores <- {
  v <- suppressWarnings(as.integer(Sys.getenv("NCPUS")))
  if (!is.na(v) && v > 0L) max(1L, v - 1L) else 4L
}

n_rep_obj     <- 100
n_rep_valid   <- 300
n_random_starts <- 8
maxit_nm      <- 100

seed_objective    <- 1000  + (JOB_INDEX - 1L) * 10000L
seed_validation   <- 50000 + (JOB_INDEX - 1L) * 10000L
seed_random_starts <- 123  + (JOB_INDEX - 1L) * 10000L

lower_beta <- 1e-5
upper_beta <- 0.10

# Epidemiological parameters
GAMMA_CLEAR    <- 1 / 387
ADMISSION_PREV <- 0.05
INIT_PREV      <- 0.02
alpha          <- 0       # transfer reduction for infected patients (0 = none)
gamma          <- GAMMA_CLEAR

# Data / model parameters used by load_data.R
MAX_P_TR <- 0.60
DEFAULT_LOS <- c(
  "MCO" = 5.5, "SSR" = 32.0, "MCO/SSR" = 7.0, "PSY" = 60.0,
  "HAD" = 22.0, "CLCC" = 6.0, "Other" = 8.0, "Unknown" = 7.0
)

# Paths
PROJECT_ROOT <- Sys.getenv("ARCANE_ROOT", unset = "/media/kevinNFS2/rany")
JOB_DIR      <- file.path(PROJECT_ROOT, "optim_cluster_jobs")
DATA_DIR     <- file.path(JOB_DIR, "data")
SHARED_DIR   <- file.path(JOB_DIR, "shared")
OUT_DIR      <- file.path(JOB_DIR, "Outputs", "france",
                          sprintf("job_%02d", JOB_INDEX))
dir.create(OUT_DIR, recursive = TRUE, showWarnings = FALSE)

# Optional warm start (from a prior run — rename to warm_start_france.rds)
warm_start_file <- file.path(JOB_DIR, "warm_start_france.rds")

# =============================================================================
# 1. LOAD DATA + BUILD STRUCTURAL PARAMETERS
# =============================================================================
message("=== FRANCE-WIDE  job ", JOB_INDEX, " ===")
message("Loading data from: ", DATA_DIR)
source(file.path(SHARED_DIR, "load_data.R"))

# Set simulation-time constants
Tmax            <- as.integer(2 * 365L)   # 2-year run
last_year_start <- Tmax - 364L
last_year_len   <- 365L
prev_init_etab  <- rep(INIT_PREV, H)
pi_vec          <- rep(ADMISSION_PREV, H)

message("H = ", H, "  |  types: ", paste(names(incidence_obs), collapse=", "))

# =============================================================================
# 2. CHECKPOINT PATHS
# =============================================================================
run_id         <- format(Sys.time(), "%Y%m%d_%H%M%S")
checkpoint_dir <- file.path(OUT_DIR, paste0("run_", run_id))
dir.create(checkpoint_dir, recursive = TRUE, showWarnings = FALSE)

checkpoint_best_file <- file.path(checkpoint_dir, "checkpoint_best_beta.rds")
checkpoint_last_file <- file.path(checkpoint_dir, "checkpoint_last_eval.rds")
history_file         <- file.path(checkpoint_dir, "history_objective.csv")
starts_file          <- file.path(checkpoint_dir, "starts_used.rds")
fits_file            <- file.path(checkpoint_dir, "fits_nm.rds")
final_file           <- file.path(checkpoint_dir, "final_validation.rds")
validation_csv       <- file.path(checkpoint_dir, "validation_summary.csv")

# =============================================================================
# 3. PARALLEL CLUSTER
# =============================================================================
message("Starting FORK cluster: ", n_cores, " workers")
if (exists("cl") && inherits(cl, "cluster")) {
  try(stopCluster(cl), silent = TRUE)
}
cl <- makeCluster(n_cores, type = "FORK")

rep_chunks       <- split(seq_len(n_rep_obj),
                          rep(seq_len(n_cores), length.out = n_rep_obj))
rep_chunks_valid <- split(seq_len(n_rep_valid),
                          rep(seq_len(n_cores), length.out = n_rep_valid))

# =============================================================================
# 4. SOURCE SIMULATION + OBJECTIVE
# =============================================================================
eval_counter <- 0L
best_value   <- Inf
source(file.path(SHARED_DIR, "sim_core.R"))

# =============================================================================
# 5. WARM START
# =============================================================================
if (file.exists(warm_start_file)) {
  ws <- readRDS(warm_start_file)
  beta_start <- ws$beta_type_opt[names(incidence_obs)]
  beta_start[is.na(beta_start)] <- sqrt(lower_beta * upper_beta)
  message("Warm start loaded.")
} else {
  beta_start <- rep(sqrt(lower_beta * upper_beta), length(incidence_obs))
  names(beta_start) <- names(incidence_obs)
  message("No warm start — using mid-range defaults.")
}
beta_start <- pmin(pmax(beta_start, lower_beta), upper_beta)

# =============================================================================
# 6. STARTING POINTS  (same structure as original: structured + random)
# =============================================================================
starts <- list()
starts[[1]] <- log(beta_start)                                    # warm start as-is
starts[[2]] <- log(pmin(beta_start * 1.50, upper_beta))           # scale up ×1.5
starts[[3]] <- log(pmax(beta_start * 0.67, lower_beta))           # scale down ×0.67
starts[[4]] <- log(pmin(pmax(beta_start * 2.00, lower_beta),
                        upper_beta))                               # scale up ×2

set.seed(seed_random_starts)
for (s in seq_len(n_random_starts)) {
  br <- beta_start * exp(runif(length(beta_start), log(0.25), log(4)))
  br <- pmin(pmax(br, lower_beta), upper_beta)
  starts[[length(starts) + 1]] <- log(br[names(incidence_obs)])
}

starts <- lapply(starts, function(x) {
  x <- x[names(incidence_obs)]
  pmin(pmax(x, lower_log), upper_log)
})
names(starts) <- paste0("start_", seq_along(starts))

saveRDS(list(datetime = Sys.time(), starts_log = starts,
             starts_beta = lapply(starts, exp),
             beta_start = beta_start, incidence_obs = incidence_obs),
        starts_file)

cat("Starting points:\n"); print(lapply(starts, exp))

# =============================================================================
# 7. NELDER-MEAD + RECOVERY + VALIDATION
# =============================================================================
tryCatch({

  fits <- run_nelder_mead(starts, fits_file)

  recovery   <- recover_best_beta(fits, checkpoint_best_file)
  beta_type_opt     <- recovery$beta_type_opt
  beta_type_log_opt <- recovery$beta_type_log_opt

  beta_opt <- beta_type_opt[as.character(type_etab_calib)]
  if (anyNA(beta_opt)) {
    beta_opt[is.na(beta_opt)] <- mean(beta_type_opt, na.rm = TRUE)
  }

  cat("\nOptimal beta per type:\n"); print(round(beta_type_opt, 6))

  val <- run_validation(beta_opt, rep_chunks_valid, seed_validation)

  validation_summary <- data.frame(
    scope              = "France",
    region             = "All",
    job_index          = JOB_INDEX,
    type               = names(incidence_obs),
    beta               = as.numeric(beta_type_opt[names(incidence_obs)]),
    incidence_obs      = as.numeric(incidence_obs),
    incidence_sim_mean = as.numeric(val$inc_mean),
    incidence_sim_sd   = as.numeric(val$inc_sd),
    incidence_sim_se   = as.numeric(val$inc_se),
    diff               = as.numeric(val$diff),
    sse                = as.numeric(val$sse_by_type),
    sse_total          = val$sse_total,
    stringsAsFactors   = FALSE
  )

  final_object <- list(
    datetime = Sys.time(), scope = "France", job_index = JOB_INDEX,
    beta_type_opt = beta_type_opt, beta_type_log_opt = beta_type_log_opt,
    beta_opt = beta_opt, incidence_obs = incidence_obs,
    validation = val, validation_summary = validation_summary,
    fits = recovery$fits_values, best_fit_id = recovery$best_fit_id,
    n_rep_obj = n_rep_obj, n_rep_valid = n_rep_valid, n_cores = n_cores,
    checkpoint_dir = checkpoint_dir
  )

  safe_saveRDS(final_object, final_file)
  write.csv2(validation_summary, file = validation_csv, row.names = FALSE)

  cat("\n=== SUMMARY ===\n")
  cat("SSE total =", round(val$sse_total, 6), "\n")
  cat("Outputs  -> ", checkpoint_dir, "\n")
  print(validation_summary[, c("type","beta","incidence_obs",
                               "incidence_sim_mean","sse")])

}, finally = {
  message("Stopping cluster ...")
  try(stopCluster(cl), silent = TRUE)
})
