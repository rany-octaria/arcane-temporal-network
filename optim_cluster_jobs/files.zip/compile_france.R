# =============================================================================
# compile_france.R  —  aggregate all 10 France-wide job results
# =============================================================================
# Run after all 10 France jobs finish:
#   Rscript --vanilla optim_cluster_jobs/compile_france.R
# =============================================================================

library(dplyr)

PROJECT_ROOT <- Sys.getenv("ARCANE_ROOT", unset = getwd())
france_dir   <- file.path(PROJECT_ROOT, "optim_cluster_jobs",
                           "Outputs", "france")
out_dir      <- file.path(PROJECT_ROOT, "optim_cluster_jobs",
                           "Outputs", "france", "compiled")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

# ── 1. Find all final_validation.rds files ────────────────────────────────────
rds_files <- list.files(france_dir, pattern = "final_validation\\.rds$",
                         recursive = TRUE, full.names = TRUE)
rds_files <- rds_files[!grepl("/compiled/", rds_files)]

if (length(rds_files) == 0) stop("No final_validation.rds files found in ", france_dir)
message("Found ", length(rds_files), " completed France jobs.")

# ── 2. Load all results ───────────────────────────────────────────────────────
results <- lapply(rds_files, readRDS)
sse_totals <- sapply(results, function(r) r$validation$sse_total)
job_indices <- sapply(results, function(r) r$job_index)

cat("\nSSE by job:\n")
print(data.frame(job = job_indices, sse = round(sse_totals, 6))[order(sse_totals), ])

# ── 3. Best run = lowest SSE ──────────────────────────────────────────────────
best_idx    <- which.min(sse_totals)
best_result <- results[[best_idx]]

cat("\nBest job: ", best_result$job_index,
    "  SSE = ", round(sse_totals[best_idx], 6), "\n")
cat("Optimal beta per type:\n")
print(round(best_result$beta_type_opt, 6))

# ── 4. Validation summary: all runs stacked ───────────────────────────────────
all_summaries <- bind_rows(lapply(results, function(r) r$validation_summary))

# Highlight best run
all_summaries <- all_summaries %>%
  mutate(is_best = (job_index == best_result$job_index))

# ── 5. Beta comparison table across all runs ─────────────────────────────────
beta_comparison <- bind_rows(lapply(results, function(r) {
  data.frame(
    job_index = r$job_index,
    sse_total = r$validation$sse_total,
    t(r$beta_type_opt),
    stringsAsFactors = FALSE
  )
})) %>% arrange(sse_total)

cat("\nBeta estimates across all runs (sorted by SSE):\n")
print(beta_comparison)

# ── 6. Save compiled outputs ──────────────────────────────────────────────────
compiled <- list(
  datetime       = Sys.time(),
  n_jobs         = length(results),
  best_job_index = best_result$job_index,
  best_sse       = sse_totals[best_idx],
  best_result    = best_result,
  all_sse        = setNames(sse_totals, job_indices),
  beta_comparison = beta_comparison,
  all_summaries  = all_summaries
)

saveRDS(compiled, file.path(out_dir, "compiled_france.rds"))
write.csv2(all_summaries,  file.path(out_dir, "all_runs_summary.csv"),     row.names = FALSE)
write.csv2(beta_comparison, file.path(out_dir, "beta_comparison_runs.csv"), row.names = FALSE)

# Save the best beta as the warm start for the region model
saveRDS(best_result,
        file.path(PROJECT_ROOT, "optim_cluster_jobs", "warm_start_france.rds"))

cat("\nCompiled outputs saved to:", out_dir, "\n")
cat("warm_start_france.rds saved for use as region warm start.\n")
