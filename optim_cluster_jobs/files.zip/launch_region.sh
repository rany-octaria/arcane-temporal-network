#!/bin/bash
# =============================================================================
# launch.sh  —  submit one job per French region
# =============================================================================
# N_REGIONS: check the actual count BEFORE submitting by running this on the
# cluster login node:
#   Rscript --vanilla -e "
#     fl <- readRDS('optim_cluster_jobs/data/facility_level_final.RDS')
#     fl <- dplyr::rename(fl, region=region)
#     cat(sort(unique(fl\$region[fl\$region != 'Unknown'])), sep='\n')
#   "
# Then set N_REGIONS below to the count printed.
# =============================================================================
N_REGIONS=13   # ← verify from your data before submitting

cd /media/kevinNFS2/rany || exit 1

for num in $(seq 1 $N_REGIONS)
do
  echo "Submitting region job $num/$N_REGIONS  (jobindex=$num)"
  qsub \
    -q mem128G \
    -l nodes=bioclustnew04:ppn=16 \
    -l walltime=48:00:00 \
    -v jobindex=$num \
    optim_cluster_jobs/region/script.sh
done
echo "All $N_REGIONS region jobs submitted. Monitor: qstat -u kevin"
